# Socket.io Chat App using AngularJS

` bower install `

` npm install `

Running on port: 8080